 <h1 align="center"> LENNIE-W  </h1>
<p align="center"> LENNIE W, A Simple WhatsApp user BOT, Created by Lenox Were,to help you enhance your interaction with your WhatsApp.
</p>
<h1 align="center">
 
<u> 𝐌𝐀𝐃𝐄 𝐁𝐘 𝐋𝐄𝐍𝐎𝐗-𝐖 </u> </h1>

<p align="center">
  <a href="https://github.com/lenodewere/Lennie-W">
    <img alt="Lennie-W" height="300" src="https://telegra.ph/file/758083800a621d384a99b.jpg">
  </a>
</p>

<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=LENNIE+W+WHATSAPP+BOT" alt="">
</p>
   
#
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-Lenox-red.svg?style=for-the-badge&logo=github"></a>
</p>



### DEPLOYMENT ###

✨DEPLOY ON HEROKU 
   
 # ❗USE PAIR CODE IF QR CODE ISN'T WORKING❗
 `we are currently working on it`

 `Then`
   - ***Click [`FORK`](https://github.com/lenodewere/Lennie-W) and `Star ⭐ Repository` for Courage.***
   
   1.  ***`Get Session` by [`SCANING QR`](https://lennie-W-qr.onrender.com)
     Or
[`SCANING QR SERVER TWO`](https://lennieqrb-a0a1bd0f905e.herokuapp.com/)
 

2. [`PAIRING CODE`](https://lenniepairer2-4641154cfcaa.herokuapp.com/pair) Then `Go-to Whatapp>Three dots>Linked Devices`***
   - You will get a session ID in WhatsApp, copy the ID only & link your WhatsApp.
   - **If you don't have an account on [Heroku](https://signup.heroku.com/), [create an account now](https://signup.heroku.com/).**
   - ***Now [DEPLOY](https://dashboard.heroku.com/new?template=https://github.com/lenodewere/Lennie-W).***


## Contributions

Contributions to Lenny-W are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

## License

The LENNIE W is released under the [Apache License](                        http://www.apache.org/licenses/).

Enjoy the diverse features of the Lennie-W  to enhance your conversations and make your WhatsApp experience more interesting!

## Developer:

- [**Instagram**](https://www.instagram.com/im_lennie)
- [**WhatsApp**](https://wa.me/254715343733)
- [**Facebook**](
https://www.facebook.com/lenode.khns) 
- [**Twitter**](https://x.com/official_lenny6) 

<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=THANK+YOU+FOR+SUPPORT" alt="">
</p>

